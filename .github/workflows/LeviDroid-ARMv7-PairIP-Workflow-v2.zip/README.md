# ARMv7 PairIP fix build workflow

This bundle contains a GitHub Actions workflow and the source patcher it runs. Use it in a writable fork of `sang765/LeviDroid-Modder` on branch `dev` (or another branch based on that source).

## Install

Copy the included `tools/` and `.github/` directories into the repository root, preserving their paths. Commit and push both files together. This update no longer relies only on the checkout action's submodule option: it runs `git submodule sync --recursive` and `git submodule update --init --recursive` explicitly, then prints submodule revisions before validating the files. The workflow starts automatically on that push, or it can be started manually from **Actions → ARMv7 PairIP Fix Build → Run workflow**.

The job checks out the full source, explicitly initializes all nested native submodules in a separate diagnostic step, verifies the ARMv7 preloader and libHttpClient sources, sets up Java 21, Android SDK, NDK r28c and Xmake, applies the targeted `GamePackageManager.kt` patch, builds `:app:assembleDebug`, validates that the selected APK contains 32-bit ARM ELF libraries, and uploads only the `armeabi-v7a` APK plus SHA-256 file. If a native submodule is absent, the log now identifies the exact missing path instead of silently failing in a chained `test` command.

## Important

- The workflow does not push source changes back to the repository; the source patch is applied in the temporary Actions runner before the build.
- The artifact is a debug-signed APK. It may not install as an in-place update over the store/release-signed launcher.
- The workflow cannot create missing proprietary ARMv7 Minecraft libraries. It changes extraction and load order, then reports a clear error if the installed Minecraft package does not provide PairIP for the runtime ABI.
- A successful build is not proof that Minecraft starts; test the APK on the target Android device and inspect the next launch log.
