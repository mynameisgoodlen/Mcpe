#!/usr/bin/env python3
"""Apply the ARMv7 native-dependency and split-APK extraction fix."""
from pathlib import Path
import sys

TARGET = Path("app/src/main/java/org/levimc/launcher/core/minecraft/GamePackageManager.kt")
MARKER = "ARMV7_PAIRIP_FIX_V2"

REPLACEMENTS = [
    (
'''    // Lazy: nativeLibDir is only assigned in the init block below.
    private val requiredLibs by lazy {
        buildList {
            add("libc++_shared.so")
            add("libfmod.so")
            add("libMediaDecoders_Android.so")
            if (shouldLoadMallocRedirect()) {
                add("libMallocRedirect.so")
            }
            add("libminecraftpe.so")
            addAll(patchInjectedLibs)
        }.toTypedArray()
    }

    // shortcut: patch builds on the pre-1.21.110 legacy load path in
    // MinecraftRuntimePreparer are not covered by this.
    private val patchInjectedLibs: List<String> by lazy {
        val known = setOf(
            "libc++_shared.so",
            "libfmod.so",
            "libMediaDecoders_Android.so",
            "libMallocRedirect.so",
            "libHttpClient.Android.so",
            "libPlayFabMultiplayer.so",
            "libmaesdk.so",
            "libgxcore.so",
            "libbgxcore.so",
        )
        val ordered = mutableListOf<String>()
        val visited = mutableSetOf<String>()
        fun visit(name: String) {
            if (!visited.add(name)) return
            for (dep in ElfNeededReader.readNeeded(File(nativeLibDir, name))) {
                if (!known.contains(dep) && File(nativeLibDir, dep).exists()) {
                    visit(dep)
                }
            }
            if (name != "libminecraftpe.so" && !known.contains(name)) {
                ordered.add(name)
            }
        }
        visit("libminecraftpe.so")
        ordered
    }
''',
'''    // ARMV7_PAIRIP_FIX_V2
    // Keep extraction independent from ELF dependency discovery. The library
    // cache is populated before minecraftDependencies is evaluated.
    private val baseRequiredLibs by lazy {
        buildList {
            add("libc++_shared.so")
            add("libfmod.so")
            add("libMediaDecoders_Android.so")
            if (shouldLoadMallocRedirect()) {
                add("libMallocRedirect.so")
            }
            add("libminecraftpe.so")
        }.toTypedArray()
    }

    // Resolve the full DT_NEEDED graph in post-order so every dependency is
    // loaded before the library that needs it. This includes PairIP and any
    // PlayFab/MAE SDK library only when the ELF metadata actually requires it.
    private val minecraftDependencies: List<String> by lazy {
        val ordered = mutableListOf<String>()
        val visited = mutableSetOf<String>()
        val preloaded = buildSet {
            addAll(baseRequiredLibs.filterNot { it == "libminecraftpe.so" })
            if (shouldLoadHttpClient()) add("libHttpClient.Android.so")
            if (shouldLoadMallocRedirect()) {
                add("libPlayFabMultiplayer.so")
                add("libmaesdk.so")
                add("libgxcore.so")
            }
        }
        fun visit(name: String) {
            if (!visited.add(name)) return
            for (dep in ElfNeededReader.readNeeded(File(nativeLibDir, name))) {
                if (dep == "libminecraftpe.so" || dep in preloaded) continue
                val dependencyFile = File(nativeLibDir, dep)
                if (dependencyFile.isFile && dependencyFile.length() > 0L) {
                    visit(dep)
                    if (dep !in ordered) ordered.add(dep)
                } else {
                    Log.w(TAG, "Native dependency $dep required by $name was not extracted")
                }
            }
        }
        visit("libminecraftpe.so")
        ordered
    }

    // These are genuine launcher/game SDK libraries, not injected patch
    // loaders. Never rewrite their DT_NEEDED edges with PatchDependencyPatcher.
    private val patchInjectedLibs: List<String> by lazy {
        val known = setOf(
            "libc++_shared.so",
            "libfmod.so",
            "libMediaDecoders_Android.so",
            "libMallocRedirect.so",
            "libHttpClient.Android.so",
            "libPlayFabMultiplayer.so",
            "libmaesdk.so",
            "libgxcore.so",
            "libbgxcore.so",
            "libpairipcore.so",
        )
        minecraftDependencies.filterNot { it in known }
    }

    private val requiredLibs by lazy {
        (baseRequiredLibs.dropLast(1) + minecraftDependencies + baseRequiredLibs.last())
            .distinct()
            .toTypedArray()
    }
'''
    ),
    (
'''    private val extractableLibs by lazy { requiredLibs + optionalLibs }
''',
'''    // Fixed libraries are extracted and cache-validated separately from the
    // dynamic DT_NEEDED graph, which can only be read after extraction.
    private val extractableLibs by lazy { baseRequiredLibs + optionalLibs }
'''
    ),
    (
'''            // Installed Play APKs keep native libraries in nativeLibraryDir,
            // the base APK, and ABI split APKs. Refresh all locations on cache hits.
            if (version == null || version.isInstalled) {
                val appInfo = requireNotNull(packageContext).applicationInfo
                extractExtraLibsFromNativeDir(appInfo.nativeLibraryDir, outputDir)
            }
            apkFiles.forEach { extractExtraLibs(it.absolutePath, outputDir, getDeviceAbi()) }
            validatePairIpDependency(outputDir)
''',
'''            // Installed Play APKs put native libraries in base/split APKs and
            // nativeLibraryDir. Sweep all locations even on a cache hit.
            if (version == null || version.isInstalled) {
                val appInfo = requireNotNull(packageContext).applicationInfo
                extractExtraLibsFromNativeDir(appInfo.nativeLibraryDir, outputDir)
            }
            apkFiles.forEach { extractExtraLibs(it.absolutePath, outputDir, getDeviceAbi()) }
'''
    ),
    (
'''        if (version == null || version.isInstalled) {
            val appInfo = requireNotNull(packageContext).applicationInfo
            if (File(appInfo.nativeLibraryDir).isDirectory) {
                copyFromNativeDir(appInfo.nativeLibraryDir, outputDir, remaining)

            }
        }
        for (apk in apkFiles) {
            if (remaining.isEmpty()) break
            extractFromApk(apk.absolutePath, outputDir, getDeviceAbi(), remaining)
        }
''',
'''        if (version == null || version.isInstalled) {
            val appInfo = requireNotNull(packageContext).applicationInfo
            if (File(appInfo.nativeLibraryDir).isDirectory) {
                copyFromNativeDir(appInfo.nativeLibraryDir, outputDir, remaining)
                extractExtraLibsFromNativeDir(appInfo.nativeLibraryDir, outputDir, overwrite = true)
            }
        }
        for (apk in apkFiles) {
            if (remaining.isEmpty()) break
            extractFromApk(apk.absolutePath, outputDir, getDeviceAbi(), remaining)
        }
        // The fixed set may already be complete from the base APK. Still scan
        // every split because PairIP/SDK dependencies can live in another split.
        apkFiles.forEach { extractExtraLibs(it.absolutePath, outputDir, getDeviceAbi(), overwrite = true) }
        validatePairIpDependency(outputDir)
'''
    ),
    (
'''    private fun extractFromApk(apkPath: String, outputDir: File, abi: String, remaining: MutableSet<String>) {
''',
'''    private fun validatePairIpDependency(outputDir: File) {
        val minecraft = File(outputDir, "libminecraftpe.so")
        if (!minecraft.isFile) return
        if ("libpairipcore.so" in ElfNeededReader.readNeeded(minecraft)) {
            val pairIp = File(outputDir, "libpairipcore.so")
            if (!pairIp.isFile || pairIp.length() == 0L) {
                throw IOException(
                    "Minecraft ${gameVersionName.orEmpty()} requires libpairipcore.so, " +
                        "but no matching ${getDeviceAbi()} library was found in its installed " +
                        "native library directory, base APK, or split APKs"
                )
            }
        }
    }

    private fun extractExtraLibsFromNativeDir(sourceDir: String, outputDir: File, overwrite: Boolean = false) {
        val source = File(sourceDir)
        source.listFiles()?.forEach { sourceFile ->
            if (!sourceFile.isFile || !sourceFile.name.endsWith(".so") || sourceFile.name in extractableLibs) {
                return@forEach
            }
            val output = File(outputDir, sourceFile.name)
            if (!overwrite && output.exists() && output.length() == sourceFile.length()) return@forEach
            sourceFile.inputStream().use { input ->
                copyStreamToReadOnlyFile(input, output, sourceFile.length())
            }
            report("Copied extra lib ${sourceFile.name} from native lib directory")
        }
    }

    private fun extractFromApk(apkPath: String, outputDir: File, abi: String, remaining: MutableSet<String>) {
'''
    ),
    (
'''                }
                extractExtraLibs(apkPath, outputDir, abi)
            }
''',
'''                }
            }
'''
    ),
    (
'''    private fun extractExtraLibs(apkPath: String, outputDir: File, abi: String) {
''',
'''    private fun extractExtraLibs(apkPath: String, outputDir: File, abi: String, overwrite: Boolean = false) {
'''
    ),
    (
'''                    if (output.exists() && output.length() == entry.size) continue
''',
'''                    if (!overwrite && output.exists() && output.length() == entry.size) continue
'''
    ),
    (
'''    private fun getCacheRequiredLibs(): Array<String> {
        return if (shouldLoadHttpClient()) {
            requiredLibs + optionalLibs
        } else {
            requiredLibs
        }
    }
''',
'''    private fun getCacheRequiredLibs(): Array<String> {
        return if (shouldLoadHttpClient()) extractableLibs else baseRequiredLibs
    }
'''
    ),
    (
'''        val allLibs = if (android.os.Process.is64Bit()) {
            requiredLibs + systemLoadedLibs
        } else {
            requiredLibs + systemLoadedLibs.filterNot { it == "libgxcore.so" }
        }
''',
'''        // A system SDK may also be a DT_NEEDED dependency of libminecraftpe.
        // In that case it is already present in requiredLibs and must not be
        // loaded a second time from the trailing SDK list.
        val remainingSystemLibs = systemLoadedLibs.filterNot { it in requiredLibs }
        val allLibs = if (android.os.Process.is64Bit()) {
            requiredLibs + remainingSystemLibs
        } else {
            requiredLibs + remainingSystemLibs.filterNot { it == "libgxcore.so" }
        }
'''
    ),
    (
'''    private fun dropUnusedPatchDeps(listener: MinecraftRuntimePreparer.ProgressListener?) {
        val gameLib = File(nativeLibDir, "libminecraftpe.so")
        for (lib in patchInjectedLibs) {
            try {
''',
'''    private fun dropUnusedPatchDeps(listener: MinecraftRuntimePreparer.ProgressListener?) {
        val gameLib = File(nativeLibDir, "libminecraftpe.so")
        for (lib in patchInjectedLibs) {
            // PairIP and the official SDK dependencies are excluded from
            // patchInjectedLibs; retain this final guard for PairIP as well.
            if (lib == "libpairipcore.so") continue
            try {
'''
    ),
    (
'''        private const val EXTRACTOR_VERSION = 3
''',
'''        private const val EXTRACTOR_VERSION = 4
'''
    ),
]


def main() -> int:
    if not TARGET.is_file():
        print(f"ERROR: {TARGET} not found. Run this from the LeviDroid-Modder repository root.", file=sys.stderr)
        return 2

    source = TARGET.read_text(encoding="utf-8")
    if MARKER in source:
        print("ARMv7 PairIP/split-library fix v2 is already applied; no changes made.")
        return 0

    updated = source
    for index, (old, new) in enumerate(REPLACEMENTS, start=1):
        count = updated.count(old)
        if count != 1:
            print(
                f"ERROR: expected exactly one source match for patch section {index}, found {count}. "
                "The upstream source may have changed; refusing a partial patch.",
                file=sys.stderr,
            )
            return 3
        updated = updated.replace(old, new, 1)

    guards = [
        "private val minecraftDependencies: List<String> by lazy",
        '"libpairipcore.so"',
        "private val extractableLibs by lazy { baseRequiredLibs + optionalLibs }",
        "val remainingSystemLibs = systemLoadedLibs.filterNot { it in requiredLibs }",
        "overwrite = true",
    ]
    missing = [item for item in guards if item not in updated]
    if missing:
        print(f"ERROR: post-patch invariant(s) missing: {missing}", file=sys.stderr)
        return 4

    TARGET.write_text(updated, encoding="utf-8")
    print(f"Applied ARMv7 PairIP/split-library fix to {TARGET}")
    print("Changes: scan all installed APK splits and nativeLibraryDir; refresh extras on cache misses; discover/load the real DT_NEEDED dependency graph before libminecraftpe; avoid duplicate SDK loads; preserve PairIP/official SDK DT_NEEDED edges; invalidate old cache metadata.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
