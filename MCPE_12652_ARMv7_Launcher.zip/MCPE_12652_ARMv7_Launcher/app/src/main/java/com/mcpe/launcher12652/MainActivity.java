package com.mcpe.launcher12652;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A lightweight launcher for the official Minecraft Bedrock app.
 * It does not contain game binaries and does not bypass purchase/licence checks.
 */
public final class MainActivity extends Activity {
    private static final String MINECRAFT_PACKAGE = "com.mojang.minecraftpe";
    private static final String TARGET_VERSION = "1.26.52";
    private TextView statusView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (statusView != null) refreshStatus();
    }

    private void buildScreen() {
        int pad = dp(24);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("MCPE Launcher");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(0xFF1B251C);
        title.setGravity(Gravity.CENTER);
        content.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Launcher target: Minecraft Bedrock 1.26.52");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFF4A554B);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleParams = matchWrap();
        subtitleParams.topMargin = dp(12);
        content.addView(subtitle, subtitleParams);

        statusView = new TextView(this);
        statusView.setTextSize(15);
        statusView.setTextColor(0xFF263328);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(16), dp(18), dp(16), dp(18));
        statusView.setBackgroundColor(0xFFE8EEE8);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(28);
        content.addView(statusView, statusParams);

        Button launchButton = new Button(this);
        launchButton.setText("LAUNCH MINECRAFT");
        launchButton.setAllCaps(false);
        launchButton.setTextSize(17);
        LinearLayout.LayoutParams launchParams = matchWrap();
        launchParams.topMargin = dp(22);
        content.addView(launchButton, launchParams);
        launchButton.setOnClickListener(v -> launchMinecraft());

        Button refreshButton = new Button(this);
        refreshButton.setText("Refresh installed version");
        refreshButton.setAllCaps(false);
        LinearLayout.LayoutParams refreshParams = matchWrap();
        refreshParams.topMargin = dp(8);
        content.addView(refreshButton, refreshParams);
        refreshButton.setOnClickListener(v -> refreshStatus());

        TextView note = new TextView(this);
        note.setText("This launcher opens the official Minecraft app already installed on this device. It does not install the game or bypass account, purchase, or licence checks.");
        note.setTextSize(13);
        note.setTextColor(0xFF59635A);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = matchWrap();
        noteParams.topMargin = dp(24);
        content.addView(note, noteParams);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        setContentView(scroll);
    }

    private void refreshStatus() {
        if (statusView == null) return;
        try {
            PackageInfo info = getPackageManager().getPackageInfo(MINECRAFT_PACKAGE, 0);
            String installedVersion = info.versionName == null ? "unknown" : info.versionName;
            String versionStatus = installedVersion.contains(TARGET_VERSION)
                    ? "Target version detected."
                    : "The installed version does not appear to match the target.";
            statusView.setText("Minecraft: INSTALLED\nInstalled version: " + installedVersion
                    + "\nTarget version: " + TARGET_VERSION + "\n" + versionStatus);
        } catch (PackageManager.NameNotFoundException e) {
            statusView.setText("Minecraft: NOT FOUND\nInstall the official Minecraft app first, then return here.");
        } catch (RuntimeException e) {
            statusView.setText("Could not read Minecraft's installed version. Try refreshing or launch the app directly.");
        }
    }

    private void launchMinecraft() {
        try {
            Intent launchIntent = getPackageManager().getLaunchIntentForPackage(MINECRAFT_PACKAGE);
            if (launchIntent == null) {
                new AlertDialog.Builder(this)
                        .setTitle("Minecraft not found")
                        .setMessage("The official Minecraft app could not be launched. Confirm that it is installed and enabled, then try again. This launcher cannot repair purchase or licence errors inside Minecraft.")
                        .setPositiveButton("OK", (dialog, which) -> refreshStatus())
                        .show();
                return;
            }
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launchIntent);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, "Android could not open the installed Minecraft app.", Toast.LENGTH_LONG).show();
        }
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
