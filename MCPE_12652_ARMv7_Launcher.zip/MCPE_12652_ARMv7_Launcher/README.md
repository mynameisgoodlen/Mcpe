# MCPE 1.26.52 Launcher (Android / ARMv7-compatible)

A small Java Android app that checks for the official Minecraft Bedrock package (`com.mojang.minecraftpe`), shows its installed version, and launches it using Android's normal package launch intent.

## What this does

- Runs on Android 6.0+ (minimum API 23), including Android 10 devices with 32-bit ARM userspace.
- Uses no native libraries of its own, so there is no 64-bit native-code requirement; the same APK can run on supported 32-bit and 64-bit Android systems.
- Displays the installed Minecraft version and warns if it does not appear to match `1.26.52`.
- Opens the existing Minecraft installation only.

## What this does not do

- This project is not Minecraft and does not contain `libminecraftpe.so` or the other game split APK contents.
- It does not install missing split APKs, patch Minecraft, circumvent Google Play purchase checks, or fix in-game account/licence errors. If Minecraft itself redirects to Google Play or rejects the licence, that problem must be resolved in the official game installation/account; a separate launcher cannot legitimately override it.
- The version check is based on Android's reported `versionName`, not a cryptographic verification of the game build.

## Build with Android Studio

1. Extract this ZIP.
2. Open the `MCPE_12652_ARMv7_Launcher` folder in Android Studio.
3. Install Android SDK Platform 35 if prompted and let Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
6. Install that APK on your device. It is a debug-signed build intended for testing.

## Build through GitHub Actions

The included workflow `.github/workflows/build-apk.yml` builds the debug APK. Upload/push this project to a GitHub repository, open **Actions > Build launcher APK**, run the workflow (or push to `main`), then download the `mcpe-12652-launcher-debug-apk` artifact from the completed run.

## Package details

- Application ID: `com.mcpe.launcher12652`
- Minecraft package targeted: `com.mojang.minecraftpe`
- Minimum Android version: 6.0 (API 23)
- Target SDK: 32
- Language: Java
